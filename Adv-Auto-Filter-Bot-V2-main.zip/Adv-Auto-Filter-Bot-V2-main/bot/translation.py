#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) @AlbertEinsteinTG

class Translation(object):
    
    START_TEXT = """<b>Hey {}!!</b>
    
<b>I'm Group Managing Bot Exclusively Made For @filmsnew169</b>

<b>⚠️Note: Click On The ＳＴＡＲＴ Button Below To Get The Shared Files ✅✅</b>"""    
    
    HELP_TEXT = """
<b>Sorry, I Can't Help You!</b>
"""
    
    ABOUT_TEXT = """<b>Nothing Great About Me..!</b>
"""
